package com.itwill3.aop.java;

public interface MemberService {
	public void create();
	public void login();
	public void list();
	public void view();
	
}
