package com.itwill.user.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
	
	/*
	/user_main
	/user_write_form
	/user_write_action
	/user_login_form
	/user_login_action
	/user_logout_action
	/user_view
	/user_modify_form
	/user_modify_action
	/user_remove_action
	*/
}
