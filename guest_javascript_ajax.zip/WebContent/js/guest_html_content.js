function guest_list_content(){
	return ``;
}

function guest_main_content(){
	return `
		`;
}
function guest_modify_form_content(){
	return `
		`;
}
function guest_view_content() {
	return `
			`;
}		
function guest_write_form_content() {
	return  `
			`;
}	